// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Electricity {
    struct Seller {
        address addr;
        uint units;
        uint price;
        uint reportCount;
        bool banned;
    }

    struct Payment {
        address buyer;
        address trader;
        uint amount;
        uint timestamp;
        string paymentType; // "buy" or "bill"
    }

    struct Report {
        address reportedAddress;
        string description;
        address reporter;
        uint timestamp;
    }

    mapping(address => Seller) public sellers;
    mapping(address => bool) public isRegistered;
    address[] public sellerAddresses;
    Payment[] public payments;
    Report[] public reports;

    // --- Seller Logic ---
    function registerSeller(uint units, uint price) public {
        if (!isRegistered[msg.sender]) {
            sellers[msg.sender] = Seller(msg.sender, units, price, 0, false);
            sellerAddresses.push(msg.sender);
            isRegistered[msg.sender] = true;
        } else {
            require(!sellers[msg.sender].banned, "Banned sellers can't register again");
            sellers[msg.sender].units += units;
            sellers[msg.sender].price = price;
        }
    }

    function getSellers() public view returns (Seller[] memory) {
        Seller[] memory sList = new Seller[](sellerAddresses.length);
        for (uint i = 0; i < sellerAddresses.length; i++) {
            sList[i] = sellers[sellerAddresses[i]];
        }
        return sList;
    }

    function buyElectricity(address sellerAddr, uint quantity) public payable {
        Seller storage s = sellers[sellerAddr];
        require(!s.banned, "This seller is banned");
        require(s.units >= quantity, "Not enough units available");
        require(msg.value >= (s.price * quantity), "Insufficient payment");

        s.units -= quantity;
        payable(sellerAddr).transfer(msg.value);

        payments.push(Payment({
            buyer: msg.sender,
            trader: sellerAddr,
            amount: msg.value,
            timestamp: block.timestamp,
            paymentType: "buy"
        }));
    }

    function payBill(address trader) public payable {
        payments.push(Payment({
            buyer: msg.sender,
            trader: trader,
            amount: msg.value,
            timestamp: block.timestamp,
            paymentType: "bill"
        }));
        payable(trader).transfer(msg.value);
    }

    function getAllPayments() public view returns (Payment[] memory) {
        return payments;
    }

    // --- Reporting functionality ---
    function reportAddress(address _reported, string memory _description) public {
        Seller storage s = sellers[_reported];
        require(!s.banned, "Already banned");

        reports.push(Report({
            reportedAddress: _reported,
            description: _description,
            reporter: msg.sender,
            timestamp: block.timestamp
        }));

        s.reportCount++;

        if (s.reportCount >= 5) {
            s.banned = true;
        }
    }

    function getAllReports() public view returns (Report[] memory) {
        return reports;
    }
}
