const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// MySQL connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",      // use your MySQL password
    database: "electricity"
});

db.connect(err => {
    if (err) throw err;
    console.log("Connected to MySQL");
});

// POST route to save name and email
app.post("/register", (req, res) => {
    const { name, email } = req.body;
    const sql = "INSERT INTO users (name, email) VALUES (?, ?)";
    db.query(sql, [name, email], (err, result) => {
        if (err) {
            console.error("Insert error:", err);
            return res.status(500).json({ error: "Database error" });
        }
        res.json({ message: "Saved to MySQL", id: result.insertId });
    });
});

// Start server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
