// navbar.js

const navbarHTML = `
<nav style="background:#364d67; padding:10px; color:white; display:flex; gap:15px; align-items:center;">
  <a href="index.html" style="color:white; text-decoration:none;">Home</a>
  <a href="register.html" style="color:white; text-decoration:none;">Register</a>
  <a href="login.html" style="color:white; text-decoration:none;">Login</a>
 <a href="marketplace.html" style="color:white; text-decoration:none;">Marketplace</a>
  <a href="paybill.html" style="color:white; text-decoration:none;">Pay Bill</a>
  <a href="dashboard.html" style="color:white; text-decoration:none;">Dashboard</a>
  <a href="report.html" style="color:white; text-decoration:none;">Report</a>
  <a href="#" id="logoutLink" style="color:white; text-decoration:none; display:none;">Logout</a>
</nav>
`;

function loadNavbar() {
  document.body.insertAdjacentHTML('afterbegin', navbarHTML);

  const logoutLink = document.getElementById('logoutLink');

  function checkLogin() {
    const sellerSession = localStorage.getItem('sellerSession');
    if (sellerSession) {
      logoutLink.style.display = 'inline';
      // Hide login and register links when logged in
      [...document.querySelectorAll('nav a')].forEach(a => {
        if (['Login', 'Register'].includes(a.textContent)) {
          a.style.display = 'none';
        }
      });
    } else {
      logoutLink.style.display = 'none';
      [...document.querySelectorAll('nav a')].forEach(a => {
        if (['Login', 'Register'].includes(a.textContent)) {
          a.style.display = 'inline';
        }
      });
    }
  }

  logoutLink.addEventListener('click', e => {
    e.preventDefault();
    localStorage.removeItem('sellerSession');
    window.location.href = 'index.html';
  });

  checkLogin();
}

window.addEventListener('DOMContentLoaded', loadNavbar);
