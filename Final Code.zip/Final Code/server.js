require("dotenv").config();
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const axios = require("axios");
const FormData = require("form-data");

const app = express();
app.use(cors({ origin: "*" })); // TODO: restrict origin for production
app.use(express.json());

const upload = multer({
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB max file size
});

const PIN_FILE_URL = "https://api.pinata.cloud/pinning/pinFileToIPFS";
const PIN_JSON_URL = "https://api.pinata.cloud/pinning/pinJSONToIPFS";

app.post("/upload-pdf", upload.single("proof"), async (req, res) => {
  console.log("PDF upload request:", req.body.wallet, req.file?.originalname);
  try {
    if (!req.file) throw new Error("No PDF file provided");
    const form = new FormData();
    form.append("file", req.file.buffer, { filename: `${req.body.wallet}_proof.pdf` });

    const resp = await axios.post(PIN_FILE_URL, form, {
      headers: {
        ...form.getHeaders(),
        pinata_api_key: process.env.PINATA_KEY,
        pinata_secret_api_key: process.env.PINATA_SECRET,
      },
    });

    console.log("PDF uploaded to IPFS:", resp.data.IpfsHash);
    res.json({ ipfsHash: resp.data.IpfsHash });
  } catch (error) {
    console.error("PDF upload error:", error.response?.data || error.message);
    res.status(500).json({ error: "Failed to upload PDF to IPFS" });
  }
});

app.post("/upload-report", async (req, res) => {
  console.log("Report upload request:", req.body);
  try {
    const { reporter, reported, description } = req.body;
    if (!reporter || !reported || !description) throw new Error("Missing report fields");

    const json = { reporter, reported, description, timestamp: Date.now() };

    const resp = await axios.post(PIN_JSON_URL, json, {
      headers: {
        pinata_api_key: process.env.PINATA_KEY,
        pinata_secret_api_key: process.env.PINATA_SECRET,
      },
    });

    console.log("Report uploaded to IPFS:", resp.data.IpfsHash);
    res.json({ ipfsHash: resp.data.IpfsHash });
  } catch (error) {
    console.error("Report upload error:", error.response?.data || error.message);
    res.status(500).json({ error: "Failed to upload report to IPFS" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
