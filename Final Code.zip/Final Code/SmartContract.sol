// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

contract Electricity {
    struct Seller {
        address sellerAddress;
        uint256 units;
        uint256 price; // price per unit in wei
        bool isBanned;
        string proofIPFSHash;
    }

    struct Transaction {
        address buyer;
        address seller;
        uint256 amount; // wei paid
        uint256 unitsBought;
        uint256 timestamp;
        string action; // "buy" or "payBill"
    }

    struct Report {
        address reporter;
        address reported;
        string descriptionHash; // IPFS hash of report description
        uint256 timestamp;
    }

    mapping(address => Seller) public sellers;
    mapping(address => mapping(address => bool)) public hasReported;
    address[] public sellerList;

    Transaction[] public transactions;
    Report[] public reports;

    uint256 public constant BAN_THRESHOLD = 5;

    event SellerRegistered(address indexed seller, uint256 units, uint256 price, string ipfsHash);
    event SellerUpdated(address indexed seller, uint256 units, uint256 price);
    event ElectricityBought(address indexed buyer, address indexed seller, uint256 amount, uint256 units, string ipfsHash);
    event BillPaid(address indexed payer, address indexed seller, uint256 amount, uint256 units);
    event ReportSubmitted(address indexed reporter, address indexed reported, string ipfsHash);
    event SellerBanned(address indexed seller);

    // === Seller Registration ===
    function registerSeller(uint256 _units, uint256 _price, string calldata _ipfsHash) external {
        require(bytes(_ipfsHash).length > 0, "IPFS hash required");
        require(!sellers[msg.sender].isBanned, "Seller banned");
        require(sellers[msg.sender].sellerAddress == address(0), "Already registered");
        require(_units > 0 && _price > 0, "Units and price must be > 0");

        sellers[msg.sender] = Seller({
            sellerAddress: msg.sender,
            units: _units,
            price: _price,
            isBanned: false,
            proofIPFSHash: _ipfsHash
        });

        sellerList.push(msg.sender);

        emit SellerRegistered(msg.sender, _units, _price, _ipfsHash);
    }

    // === Update Units and Price ===
    function updateSeller(uint256 _units, uint256 _price) external {
        Seller storage seller = sellers[msg.sender];
        require(seller.sellerAddress != address(0), "Not registered");
        require(!seller.isBanned, "Seller is banned");
        require(_units > 0 && _price > 0, "Units and price must be > 0");

        seller.units = _units;
        seller.price = _price;

        emit SellerUpdated(msg.sender, _units, _price);
    }

    // === Buy Electricity ===
    function buyElectricity(address _seller, uint256 _units) external payable {
        Seller storage seller = sellers[_seller];
        require(!seller.isBanned, "Seller banned");
        require(seller.sellerAddress != address(0), "Seller not registered");
        require(_units > 0 && seller.units >= _units, "Invalid unit amount");

        uint256 totalPrice = seller.price * _units;
        require(msg.value >= totalPrice, "Insufficient payment");

        seller.units -= _units;
        payable(_seller).transfer(totalPrice);

        if (msg.value > totalPrice) {
            payable(msg.sender).transfer(msg.value - totalPrice); // refund excess
        }

        transactions.push(Transaction({
            buyer: msg.sender,
            seller: _seller,
            amount: totalPrice,
            unitsBought: _units,
            timestamp: block.timestamp,
            action: "buy"
        }));

        emit ElectricityBought(msg.sender, _seller, totalPrice, _units, "");
    }

    // === Pay Electricity Bill ===
    function payBill(address _seller, uint256 _units) external payable {
        Seller storage seller = sellers[_seller];
        require(!seller.isBanned, "Seller banned");
        require(seller.sellerAddress != address(0), "Seller not registered");
        require(_units > 0, "Units must be > 0");

        uint256 totalPrice = seller.price * _units;
        require(msg.value >= totalPrice, "Insufficient payment");

        payable(_seller).transfer(totalPrice);

        if (msg.value > totalPrice) {
            payable(msg.sender).transfer(msg.value - totalPrice);
        }

        transactions.push(Transaction({
            buyer: msg.sender,
            seller: _seller,
            amount: totalPrice,
            unitsBought: _units,
            timestamp: block.timestamp,
            action: "payBill"
        }));

        emit BillPaid(msg.sender, _seller, totalPrice, _units);
    }

    // === Report Fraud ===
    function reportAddress(address _reported, string calldata _ipfsHash) external {
        require(sellers[_reported].sellerAddress != address(0), "Seller not registered");
        require(!hasReported[msg.sender][_reported], "Already reported");
        require(bytes(_ipfsHash).length > 0, "IPFS hash required");

        hasReported[msg.sender][_reported] = true;

        reports.push(Report({
            reporter: msg.sender,
            reported: _reported,
            descriptionHash: _ipfsHash,
            timestamp: block.timestamp
        }));

        emit ReportSubmitted(msg.sender, _reported, _ipfsHash);

        // Ban if threshold reached
        uint256 reportCount = 0;
        for (uint i = 0; i < reports.length; i++) {
            if (reports[i].reported == _reported) {
                reportCount++;
                if (reportCount >= BAN_THRESHOLD && !sellers[_reported].isBanned) {
                    sellers[_reported].isBanned = true;
                    emit SellerBanned(_reported);
                    break;
                }
            }
        }
    }

    // === View Functions ===

    function getSellers() external view returns (address[] memory) {
        return sellerList;
    }

    function getSellerDetails(address _seller) external view returns (
        address sellerAddress,
        uint256 units,
        uint256 price,
        bool isBanned,
        string memory proofIPFSHash
    ) {
        Seller storage s = sellers[_seller];
        return (s.sellerAddress, s.units, s.price, s.isBanned, s.proofIPFSHash);
    }

    function getTransactions() external view returns (Transaction[] memory) {
        return transactions;
    }

    function getReports() external view returns (Report[] memory) {
        return reports;
    }
}
